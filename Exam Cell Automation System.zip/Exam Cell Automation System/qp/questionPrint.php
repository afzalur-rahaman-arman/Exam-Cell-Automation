<?php 
  session_start(); 
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }

?>


<!DOCTYPE html>
<html>
<head>
	<title>Question Paper Generator</title>
</head>
<body>

<?php

echo "<table border='0' align='center' width='800'>";

$conn = mysqli_connect("localhost", "root", '', "qp");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$university= $_POST["university"];
$subject= $_POST["subject"];
$subject_code=$_POST["subject_code"];
$question_type= $_POST["question_type"];
$marks=$_POST["marks"];

$time= $_POST["time"];
$date= $_POST["date"];
$set= $_POST["set"];
$eset = $_POST["everySetQuestion"];

$name=$_SESSION['username'];




echo "<tr><td align='right'><H1> $university</H1></td></tr>";
echo"<tr>";
echo"<td>Subject : $subject</td>";


echo"<td colspan='2'></td>";

echo"<td align='right'>Marks : $marks</td>";
 
echo"</tr>";

echo"<tr>";
echo"<td>Subject code : $subject_code</td>";

echo"<td colspan='2'></td>";
echo"<td align='right'>Total time : $time</td>";
echo"</tr>";
echo"<tr>";
echo"<td></td>";

echo"<td colspan='2'></td>";
echo"<td align='right'>Date : $date</td>";
 
echo"</tr>";

echo "</table>";


$sql = "SELECT * FROM subject where question_type ='$question_type' and subject_code= '$subject_code' and name='$name' ";
$result = $conn->query($sql);
$arr=array();

if ($result->num_rows > 0) {
  $count=0;
  //echo $result->num_rows;
    while($row = $result->fetch_assoc()) {
    	$count= $count+1;
        $arr[$count]=$row["question"];
    }
}




$sql= $conn->query("select count(subject_code) from subject where name='afzal'");
$r=$sql->fetch_row();
// echo $r[0];
$c1=0;
if($r[0]>($set*$eset))
for ($i=1; $i <=$set ; $i++) { 
	echo "$i)<br>  ";
	for ($j=1; $j <=$eset ; $j++) { 
		echo "     $j)";
		for ($k=0; $k <10 ; $k++) { 
			if ($arr[rand($i,$r[0])]) {
				echo $arr[rand($i,$r[0])] ;
				break;
			}
			
		}

echo "<br>";
	}


	echo "<br><br>";
}

echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
$conn->close();
?>
<button onclick="myFunction()">Print this page</button>
<script>
function myFunction()
{
window.print();
}
</script>

</body>
</html>
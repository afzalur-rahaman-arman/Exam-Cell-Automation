



<?php
echo "<table border='0' align='center' width='800'>";
echo"<tr>";
echo"<td>Subject :Computer Science</td>";

echo"<td colspan='2'></td>";

echo"<td align='right'>Marks : 60</td>";
 
echo"</tr>";

echo"<tr>";
echo"<td></td>";

echo"<td colspan='2'></td>";
echo"<td align='right'>Date :11/02/2020</td>";
 
echo"</tr>";
echo"<tr>";
echo"<td></td>";

echo"<td colspan='2'></td>";
echo"<td align='right'>Time : 3Hours</td>";
 
echo"</tr>";

echo "</table>";




?>
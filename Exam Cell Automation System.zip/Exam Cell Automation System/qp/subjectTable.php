<?php

$conn= mysqli_connect("localhost", "root", '', "qp");

$sql="create table subject(
subject varchar (100) not null , 
subject_code varchar(100) not null ,
semester varchar(100) not null,
question_type varchar (100) not null,
question varchar(100) not null primary key,
chapter_number int(50) not null, 
name varchar(100) not null,
createdate timestamp default current_timestamp on update current_timestamp
)";

if(mysqli_query($conn, $sql))
echo "Successfully created..........!!!!";
else
	echo "failed.";

$conn->close();
?>


<?php

for ($i=1; $i < 10; $i++) { 
	
	echo "<br> Random".rand(1,100);
}

?>
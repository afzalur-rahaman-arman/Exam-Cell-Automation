<?php

$conn = mysqli_connect("localhost","root", '', "qp");

$sql= "create table users (
username  VARCHAR(100) NOT NULL,
 email VARCHAR(100) NOT NULL PRIMARY KEY,
  password VARCHAR(100) NOT NULL

) ";
if(mysqli_query($conn, $sql))
	echo "users TABLE created successfull";
else
	echo "error created the table";

?>
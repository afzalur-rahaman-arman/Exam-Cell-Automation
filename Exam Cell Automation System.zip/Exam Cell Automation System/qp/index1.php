<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Question paper Generator</title>
  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">
​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index.php">Home</a>
  <a class="navbar-brand" href="about.php">About</a>
  <a class="navbar-brand" href="contact.php">Contact</a>
 <a class="navbar-brand"  href="#" style="color: yellow">Create Question Paper</a>
<a class="navbar-brand" href="allQuestion.php">See all question</a>
<a class="navbar-brand" href="allSubject.php">Subject</a>
 <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;">logout</a>
</nav>
​
<div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>

      <marquee  behavior="alternate" width="100%" scrolldelay="200" >
<h3><p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>  </h3>
</marquee>
      
    <?php endif ?>
</div>


<?php 

  
  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
$conn= mysqli_connect("localhost", "root" , '' , "qp");

$subject=$_POST["subject"];
$subject_code= $_POST["subject_code"];
$semester= $_POST["semester"];
$question_type= $_POST["question_type"];
$question= $_POST["question"];
$chapter_number= $_POST["chapter_number"];
$name=$_SESSION['username'];
 $sql = "insert into subject(subject, subject_code,  semester, question_type,question, chapter_number, name) values ('$subject', '$subject_code', '$semester', '$question_type', '$question', '$chapter_number', '$name')";
 


 if(mysqli_query($conn, $sql))
  echo "<p style = 'background-color: Red'>"."Congrates Add successfull";

?>




<div class="container">

<div class="row">
    <div class="col-sm-4" style="background-color:lavender;">
      
<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
       Add Question</a>
      </h4>
    </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
         Delete Question</a>
      </h4>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
       Question Paper Generate</a>
      </h4>
    </div>
  </div>
</div>

  
    <div class="col-sm-4" style="background-color:lavenderblush;">
      <div id="collapse1" class="panel-collapse collapse in">
      <div class="panel-body">


<H1>Add Subject Question </H1>

<form action="insertSubject.php" method="POST">  <!--------- add question ----------->
  <div class="row">
 <div class="col-sm-4" style="background-color:lavenderblush;">



<div class="form-group">
  <label>Subject name</label>
  <input type="text" name="subject" class="input-group">
</div>


<div class="form-group">
  <label>Subject code</label>
  <input type="text" name="subject_code" class="input-group">
</div>


<div class="form-group">
  <label>Semester</label>
  <input type="text" name="semester" class="input-group">
</div>
</div>
<div class="col-sm-4" style="background-color:lavenderblush;">

<div class="form-group">
  <label>Question Type</label>
  <input type="text" name="question_type" class="input-group">
</div>

<div class="form-group">
  <label>Chapter Number</label>
  <input type="number" placeholder="Number only" name="chapter_number" class="input-group" >
</div>


</div>
</div>
<div class="form-group">
  <label>Question</label>
  <textarea rows="10" value="submit" type="text" name="question" class="input-group" >
  </textarea>

<div class="form-group">
<button type="submit" value="submit" class="btn btn-danger" align="center">  Submit</button>
</div>

</div>
</div>
</div>
 
 </form>

    <div id="collapse2" class="panel-collapse collapse">
      <div class="panel-body">
        


<H1>Delete Question </H1>

<form action="deleteQuestion.php" method="POST">             <!-----------delete qp ----------->
  <div class="row">
 <div class="col-sm-4" style="background-color:lavenderblush;">



<div class="form-group">
  <label>Subject code</label>
  <input type="text" name="subject_code" class="input-group">
</div>


<div class="form-group">
  <label>Question</label>
  <textarea rows="10" value="submit" type="text" name="question" class="input-group" >
  </textarea>
</div>


<div class="form-group"  align="center">
<button type="submit" value="submit" class="btn btn-danger">  Submit</button>
</div>
</div>
</div>
 
 </form>

      </div>
    </div>

    <div id="collapse3" class="panel-collapse collapse">
      <div class="panel-body">

<form action="questionPrint.php" method="POST">            <!---------------- qp --------------->

<div class="container">
  <div class="row">
    
<div class="col-sm-4" style="background-color: white">

    <div class="form-group">
  <label>University</label>
  <input type="text" name="university" class="input-group">
</div>
<div class="form-group">
  <label>Subject </label>
  <input type="text" name="subject" class="input-group">
</div><div class="form-group">
  <label>Subject code</label>
  <input type="text" name="subject_code" class="input-group">
</div>
<div class="form-group">
  <label>Semester</label>
  <input type="text" name="Semester" class="input-group">
</div>
<div class="form-group">
  <label>Every set question</label>
  <input type="number" name="everySetQuestion" class="input-group">
</div>

    </div>


    <div class="col-sm-4" style="background-color: white">
      
      <div class="form-group">
  <label>Marks</label>
  <input type="number" name="marks" min="10" max="100" class="input-group">
</div>
<div class="form-group">
  <label>Time</label>
  <input type="text" name="time" class="input-group">
</div>
<div class="form-group">
  <label>Date</label>
  <input type="text" name="date" class="input-group" placeholder="@ex- 3 Hours">
</div>


<div class="form-group">
  <label>Question Type</label>
  <input type="text" name="question_type" class="input-group">
</div>


<div class="form-group">
  <label>Set</label>
  <input type="number" name="set" min="1" max="15" class="input-group">
</div>

<div class="form-group" align="center">
<button type="submit" value="submit" class="btn btn-danger"> Submit</button>
</div>
    </div>  
  </div>
</div>

</form>


</div></div></div></div></div></div></div>
</body>
</html>
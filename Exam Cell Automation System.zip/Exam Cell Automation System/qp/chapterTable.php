<?php

$conn=mysqli_connect("localhost", "root", '', "qp");

$sql="create table chapter(

subject varchar(100) not null,
subject_code varchar(100) not null,
question_type varchar(100) not null,
semester varchar(100) not null,
chapterNumber varchar(100) not null,
question varchar(1000) not null primary key

)";

if(mysqli_query($conn, $sql))
{
	echo "Successfull";
}

$conn->close();
?>
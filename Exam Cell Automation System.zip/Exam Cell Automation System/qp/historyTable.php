<?
$conn = mysqli_connect("localhost", "root", '', "qp");
$sql = "create table history (

name varchar(100), 
university varchar(100),
subject varchar(100),
subject_code varchar(100),
marks varchar(100), 
time varchar(100),
date varchar(100),
question_type varchar(100),
set int(100)
)";
if(mysqli_query($conn, $sql))
	echo "created success full";
$conn->close();

?>
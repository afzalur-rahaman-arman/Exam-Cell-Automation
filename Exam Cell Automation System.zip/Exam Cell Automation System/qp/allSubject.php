



<!DOCTYPE html>
<html lang="en">
<head>
  <title>Question paper Generator</title>
  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">
​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index.php">Home</a>
  <a class="navbar-brand" href="about.php">About</a>
  <a class="navbar-brand" href="contact.php">Contact</a>
 <a class="navbar-brand"  href="index1.php" style="color: yellow">Create Question Paper</a>
<a class="navbar-brand" href="allQuestion.php">See all question</a>
<a class="navbar-brand" href="allSubject.php">Subject</a>
 <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;">logout</a>
</nav>
​
<div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>

      <marquee  behavior="alternate" width="100%" scrolldelay="200" >
<h3><p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>  </h3>
</marquee>
      
    <?php endif ?>
</div>



<center>
  
  <h1>Insert Subject</h1>
  <hr>
  <br>

  
<form action="allSubject.php" method="POST">
  
  <table>
    <tr>
      <th>
        Subject Code
      </th>
      <th>
        <input type="text" name="subjectcode">
      </th>
    </tr>
     <tr>
      <th>
        Subject Name
      </th>
      <th>
        <input type="text" name="subject">
      </th>
    </tr>
     <tr>
      <th>
        Sem
      </th>
      <th>
        <input type="text" name="sem">
      </th>
    </tr>
    <tr>
      <td>
        
      </td>
      <td><input type="submit" name="submit" value="submit"></td>
    </tr>
  </table>
</form>


</center>

</body>
</html>


<!-- <?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
  }
  ?> -->
  <?php

$conn= mysqli_connect("localhost", "root" , '' , "qp");

$subjectcode= $_POST["subjectcode"];
$subject=$_POST["subject"];
$sem= $_POST["sem"]; 

$name=$_SESSION['username'];

 if($name){
 $sql = "insert into subjecttable(subjectcode, subject,  sem, name) values('$subjectcode', '$subject',  '$sem', '$name')";
 if(mysqli_query($conn, $sql))
 {
  echo "<p style = 'background-color: Red'>"." Successfull";
}
else 
  echo "Failed";
}


if ($name) {

  $sql = "select * from subjecttable where name='$name'";
        $result = $conn->query($sql);
       if ($result->num_rows > 0) {
         echo "<table border ='1'>
      <tr>
        <th>
        Subject Code
        </th>
        <th>
          Subject Name
        </th>
        <th>
          Semester
        </th>
      </tr>";

      while($row = $result->fetch_assoc()) {
        echo "<tr>"."<td>".$row['subjectcode']."</td>";
         echo "<td>".$row['subject']."</td>"."<td>".$row['sem']."</td>"."</tr>";
    }
    }
echo "</table>";
}


?>
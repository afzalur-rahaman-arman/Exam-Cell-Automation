<?php



$conn= mysqli_connect("localhost", "root" , '' , "qp");



$sql1="select *from subject where subject_code='$subjectcode'";





$sql= $conn->query("select count(subject_code) from subject where name='afzal'");


$row=$sql->fetch_row();
echo $row[0];

$set=3;
$eset=2;

if ($row[0]>=($set*$eset)) {
	
for ($i=0; $i < $set; $i++) { 
	
	for ($j=1; $j<= $eset ; $j++) { 
		for ($k=0; $k < $row[0]; $k++) { 
			echo 
		}
	}
}


?>
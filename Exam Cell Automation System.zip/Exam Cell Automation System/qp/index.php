<!DOCTYPE html>
<html lang="en">
<head>
   <title>Question Paper Generator</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">
​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index.php">Home</a>
  <a class="navbar-brand" href="about.php">About</a>
  <a class="navbar-brand" href="contact.php">Contact</a>
  <a class="navbar-brand" href="login.php">Login</a>
</nav>
​

</div>  
 <div id="bottom">
<br>
<br>
<div id="boxes">
<marquee  behavior="alternate" width="100%" scrolldelay="20" >
<h3>UNIQUE FEATURES</h3>
</marquee>
<ol>
<li type="square">
A Customised solution
</li>
<li type="square">
Generates a set of various types of questions.
</li>
</ol>

</div>


<div id="boxes">
<marquee  behavior="alternate" width="100%" scrolldelay="20" >

<h3>FEEDBACK CORNER</h3>
</marquee>
<u>Teachers Feedback</u>
<ol>
<li type="square">
A brilliant effort!!  
</li>
<li type="square">
Now we will have lots of time to utilize for other constructive work.</li>
<li type="square">
It is something that we always required.</li>

</ol>
</div>
 </div>


<br><br><br>


<center>
See Question


<form action="index.php" method="post">

<table border="0">
  <tr>
    <th>
      <input type="text" name="sir" placeholder="Enter ID or name">
    </th>
    <th>
      <input type="submit" name="submit" value="submit"> 
    </th>
  </tr>
</table>

</form>


</center>


​
<div class="content">
    <!-- notification message -->
    <?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
        <h3>
          <?php 
            echo $_SESSION['success']; 
            unset($_SESSION['success']);
          ?>
        </h3>
      </div>
    <?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>

      <marquee  behavior="alternate" width="100%" scrolldelay="200" >
<h3><p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>  </h3>
</marquee>
      
    <?php endif ?>
</div>


<center>

  <?php

$conn= mysqli_connect("localhost", "root" , '' , "qp");

$name=$_POST["sir"];


if ($name) {

  $sql = "select * from subject where name='$name'";
        $result = $conn->query($sql);
       if ($result->num_rows > 0) {
         echo "<table border ='1'>
      <tr>
      <th>
      Question
      </th>
        <th>
        Subject Code
        </th>
        <th>
          Subject Name
        </th>
        <th>
          Semester
        </th>
      </tr>";

      while($row = $result->fetch_assoc()) {
        echo "<tr>"."<td>".$row['question']."</td>";
        echo ""."<td>".$row['subject_code']."</td>";
         echo "<td>".$row['subject']."</td>"."<td>".$row['semester']."</td>"."</tr>";
    }
    }
echo "</table>";
}


?>


</center>



<br>

<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>


</body>
</html>

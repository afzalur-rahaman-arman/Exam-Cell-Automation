<?php

$conn = mysqli_connect("localhost","root", '');

$sql= "create database qp";
if(mysqli_query($conn, $sql))
	echo "QP database created successfull";
else
	echo "error created the database";

?>
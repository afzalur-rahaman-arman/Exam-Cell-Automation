<?php 
  session_start(); 
  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title> Profile </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">
​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index1.php" >Home</a>
  <a href="examSchedule.php" class="navbar-brand"> <div class="btn btn-success">Exam Schedule </div> </a>
    <div class="navbar-brand">
     <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printMarksheet.php" method="POST">
      <input type="submit" value="Marksheet" name="submit">
  </form>
<?php endif ?>
    </div>
     </div>

    <div class="navbar-brand"> 
      <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printAdmitCard.php" method="POST">
      <input type="submit" value="Admit Card" name="submit1">
  </form>
<?php endif ?>
    </div>
     </div>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout </div> 
  </a>

</nav>
<br>
<br>
<br>
<br>

<?php
$conn= mysqli_connect("localhost", "root", '', "ecautomationsystem");
// $ID=$_POST["ID"];
$ID=$_SESSION['id'];


  echo "<table>
  <tr>
    <th></th> <th><h4>BGC Trust University Bangladesh</h1></center><center><h5>Office of the Controller of Examinations<h5>BGC Bidyanagar, Chandanaish, Chattagram</h5><b><h5>";
 $sql = "SELECT * FROM exam";
$result = $conn->query($sql);
if ($result->num_rows > 0)
{
    $row = $result->fetch_assoc();
        echo  $row["examname"];
} 

echo "(Session:";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
        echo  $row["session"];
}


echo ")</h5></b><p>Admit Card</p></center></th><th></th></tr>";
 
echo "<tr><td>Name    :  </td>";
echo "<td>";




 $sql = "SELECT * FROM student where id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

    $row = $result->fetch_assoc();
        echo  $row["name"];
}
echo "</td>";

echo "<td  rowspan='4'> ";

$sql="SELECT * FROM images where id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
      echo "<img src='".$row['image']."' width='100' height='100'>";
    }
echo "</td></tr>";


echo "<tr> <td>ID   :  </td><td> $ID</td></tr>";

 echo "<tr><td>Semester : </td>";
 echo "<td>";





$cgpa=1;
$credit1=1;
$credit=0;
$gpa=0;
$semester="";

$v=0;
$sql="select * from marks where id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $m=$row["marks"];
        $semester=$row["sem"];
        $subjectCode=$row["subjectcode"];
        if($m>79 && $m<=100)
            $gpa=4.0;
            elseif ($m>75 && $m<80) 
            $gpa = 3.75;
            elseif ($m>75 && $m<80) 
            $gpa = 3.75;
            elseif ($m>70 && $m<=75) 
            $gpa = 3.50;
            elseif ($m>=66 && $m<=70) 
            $gpa = 3.25;
            elseif ($m>=61 && $m<=65) 
            $gpa = 3.00;
            elseif ($m>=56 && $m<=60) 
            $gpa = 2.75;
            elseif ($m>=51 && $m<=55) 
            $gpa =2.50;
            elseif ($m>=46 && $m<=50) 
            $gpa =2.25;
            elseif ($m>=41 && $m<=45) 
            $gpa =2.00;
            else
                $gpa=0.001;
        




        $sql1="SELECT * FROM subject where subjectcode='$subjectCode' ";
        $result1=$conn->query($sql1);
        if($result1->num_rows>0)
        $row=$result1->fetch_assoc();
        $credit=$row["credit"];
        $credit1+=$credit;
        $cgpa+=$credit*$gpa;

    }





    if($semester=="1st")
{
  if ($v<1) {
    $v=1;
  }
}
if($semester=="2nd")
{
  if ($v<2) {
    $v=2;
  }
}
if($semester=="3rd")
{
  if ($v<3) {
    $v=3;
  }
}
if($semester=="4th")
{
  if ($v<4) {
    $v=4;
  }
}
if($semester=="5th")
{
  if ($v<5) {
    $v=5;
  }
}
if($semester=="6th")
{
  if ($v<6) {
    $v=6;
  }
}
if($semester=="7th")
{
  if ($v<7) {
    $v=7;
  }
}
if($semester=="8th")
{
  if ($v<8) {
    $v=8;
  }
}





}




if($v==0)
{
  $SEM="1st";
  echo $SEM;
}


if($v==1)
{
  $SEM="2nd";
  echo $SEM;
}
if($v==2)
{
  $SEM="3rd";
  echo $SEM;
}
if($v==3)
{
  $SEM="4th";
  echo $SEM;
}
if($v==4)
{
  $SEM="5th";
  echo $SEM;
}
if($v==5)
{

  $SEM="6th";
  echo $SEM;
}

if($v==6)
{
  $SEM="7th";
  echo $SEM;
}


if($v==7)
{
  $SEM="8th";
  echo $SEM;
}






// $sql="select * from marks where id='$ID'";
// $result = $conn->query($sql);
// if ($result->num_rows > 0) {
//     $row = $result->fetch_assoc();

    
//        echo row["sem"];
//     }
// echo $SEM;
echo "<tr><td> Program : </td>";

echo "<td> Bachelor of Science(Honours) in Computer Sci</td>";
echo "</tr></table>";

echo "<table border='1'>
    <tr>
        <th>Regular</th>
        <th>Retake/Improvement</th>
    </tr>
    <tr>
        <td>
            <table border='1'>
                <tr>
                    <th>Subject</th>
                    <th>Subject Code</th>
                </tr>";

       $sql="SELECT * FROM exam where sem='$SEM'";
       $result = $conn->query($sql);
       if ($result->num_rows > 0) {
       while($row = $result->fetch_assoc()) {
    	echo "<tr>
            <td align='right'> ";
        echo  $row["subjectname"];
        echo "</td>";
        echo "<td align='left'> ";
        echo  $row["subjectcode"];
        echo "</td>
            </tr>";
        }
}
       echo "</table>
           </td>";
    
echo "<td>
            <table border='1'>
                <tr>
                    <th>Subject </th>
                    <th>Subject Code</th>
                </tr>";

                $sql="SELECT * FROM ri where id='$ID'";
       $result = $conn->query($sql);
       if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        echo "<tr><td align='right'> ";
        echo  $row["subject"];
        echo "</td>";
        echo "<td align='left'> ";
        echo  $row["subjectcode"];
        echo "</td>
        </tr>";
    }
    }
        echo "</table>
        </td>";
echo "</tr> " ;
         echo "</table>";
?>
<br>
<br>
<br>
<br>

<button onclick="myFunction()">Print this page</button>
<script>
function myFunction()
{
window.print();
}
</script>
<br><br><br>



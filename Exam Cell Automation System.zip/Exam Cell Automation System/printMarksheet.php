<?php 
  session_start(); 
  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }

?>



<!DOCTYPE html>
<html lang="en">
<head>
 <title> Profile </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">
​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index1.php" >Home</a>
  <a href="examSchedule.php" class="navbar-brand"> <div class="btn btn-success">Exam Schedule </div> </a>
    <div class="navbar-brand">
     <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printMarksheet.php" method="POST">
      <input type="submit" value="Marksheet" name="submit">
  </form>
<?php endif ?>
    </div>
     </div>

    <div class="navbar-brand"> 
      <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printAdmitCard.php" method="POST">
      <input type="submit" value="Admit Card" name="submit1">
  </form>
<?php endif ?>
    </div>
     </div>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout </div> 
  </a>

</nav>
<br>
<br>


<center> 
   <form action="printMarksheet.php" method="POST">
   		 <input type="text" name="sem" placeholder="Enter Your Semester">
    	<input type="submit" value="Submit">
    
      
</form>
</center>


<?php

$conn= mysqli_connect("localhost", "root", '', "ecautomationsystem");

$ID=$_SESSION['id'];


$fname="";
$mname="";
$name="";

 $sql = "SELECT * FROM student where id='$ID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc(); 

        $name=  $row["name"];
        $fname=$row["fathername"];
        $mname=$row["mothername"];
        
}
  echo "<table>
  <tr>
    <th></th> <th><h1>BGC Trust University Bangladesh</h1><b><h5>";
echo "(Session:";
$sql = "SELECT * FROM marks where id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
        echo  $row["session"];
}


echo ")</h5></b><p>Marksheet</p></center></th><th></th></tr>";
 
 
echo "<tr><td>Name    :  </td>";
echo "<td>";
echo $name."</td>";
echo "<td  rowspan='6'> ";

$sql="SELECT * FROM images where id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
  $row = $result->fetch_assoc();
      
      echo "<img src='".$row['image']."' width='100' height='100'>";
}


echo "";
echo "</td></tr>";

echo "<tr> <td>ID   :  </td><td> $ID</td></tr>";

echo "<tr>
  <td>
    Father's Name  :
  </td>
  <td><b>".$fname."</b> 
  </td>
</tr>

<tr>
  <td>
    Mother's Name  :
  </td>
  <td><b>".$mname."</b>
  </td>
</tr>

<tr>";




$SEM="1st";
if (isset($_POST["sem"])) {
  $SEM=$_POST["sem"];
}


 echo "<tr><td>Semester :</td>";
 echo "<td>";


echo "$SEM</td> </tr>";
echo "<tr><td> Program : </td>";

echo "<td> Bachelor of Science(Honours) in Computer Science</td>";
echo "</tr>";


echo "<tr><td><center>GPA : ";//-----------------gpa-------------------

$sql="select * from marks where sem='$SEM' AND id='$ID'";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $m=$row["marks"];
        $subjectCode=$row["subjectcode"];
        if($m>79 && $m<=100)
          $gpa=4.0; 
            elseif ($m>=75 && $m<80) 
            $gpa = 3.75;
            elseif ($m>70 && $m<=75) 
            $gpa = 3.50;
            elseif ($m>=66 && $m<=70) 
              $gpa = 3.25;
            elseif ($m>=61 && $m<=65) 
            $gpa = 3.00;
            elseif ($m>=56 && $m<=60) 
            $gpa = 2.75;
            elseif ($m>=51 && $m<=55) 
            $gpa =2.50;
            elseif ($m>=46 && $m<=50) 
            $gpa =2.25;
            elseif ($m>=41 && $m<=45) 
            $gpa =2.00;
            else
                $gpa=0;
        
        $sql1="SELECT * FROM subject where subjectcode='$subjectCode' and sem='$SEM'";
        $result1=$conn->query($sql1);
        if($result1->num_rows>0)
        {
        $row=$result1->fetch_assoc();
        $credit=$row["credit"];
        }

        $credit1+=$credit;
        $Gpa+=$credit*$gpa;
    }

$totalGpa=0;
$totalGpa=$Gpa/($credit1);
echo "<b>". $totalGpa."</b>";
echo "</center></td>";

}


else {
  echo "<p style='background-color:red'>You are not in this semester.";

}

echo "<td><center>CGPA : ";////////cgpa

$cgpa=1;
$credit1=1;
$credit=0;
$gpa=0;
$sql="select * from marks where id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $m=$row["marks"];
        $subjectCode=$row["subjectcode"];
        if($m>79 && $m<=100)
            $gpa=4.0;
            elseif ($m>75 && $m<80) 
            $gpa = 3.75;
            elseif ($m>75 && $m<80) 
            $gpa = 3.75;
            elseif ($m>70 && $m<=75) 
            $gpa = 3.50;
            elseif ($m>=66 && $m<=70) 
            $gpa = 3.25;
            elseif ($m>=61 && $m<=65) 
            $gpa = 3.00;
            elseif ($m>=56 && $m<=60) 
            $gpa = 2.75;
            elseif ($m>=51 && $m<=55) 
            $gpa =2.50;
            elseif ($m>=46 && $m<=50) 
            $gpa =2.25;
            elseif ($m>=41 && $m<=45) 
            $gpa =2.00;
            else
                $gpa=0.001;
        
        $sql1="SELECT * FROM subject where subjectcode='$subjectCode' ";
        $result1=$conn->query($sql1);
        if($result1->num_rows>0)
        $row=$result1->fetch_assoc();
        $credit=$row["credit"];
        $credit1+=$credit;
        $cgpa+=$credit*$gpa;

    }
}
$totalGpa=0.01;
$totalGpa=$cgpa/($credit1-1);
echo "<b>". $totalGpa."</b>";

echo "</center>  </td>";
    echo "</tr>";
echo "</table>";


  
echo "<table border='1'> ";
echo "<tr>";
echo "<th>Subject Name</th><th>Subject Code</th><th>Marks</th>";
echo "</tr>";

$sql="SELECT * FROM marks where sem='$SEM' and id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {

    	echo "<tr><td align='right'> ";
        echo  $row["subjectname"];
        echo "</td>";
        echo "<td align='left'> ";
        echo  $row["subjectcode"];
        echo "</td>";
        echo "<td align='Center'> ";
        echo  $row["marks"];
        echo "</td></tr>";

    }
}
echo "</table>";

?>
<br>
<br>
<br>
<br>
<button onclick="myFunction()">Print this page</button>
<script>
function myFunction()
{
window.print();
}
</script>
<br>
<br>
<br>
<br>
<a href="index1.php">Go To Previous page</a>


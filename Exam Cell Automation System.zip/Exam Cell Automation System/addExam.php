<?php 
  session_start(); 

  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }
?>


<!DOCTYPE html>
<html lang="en">
<head>
 <title>Registration system PHP and MySQL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00fa9a">
​

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="admin.php" ><div class="btn btn-success">Home</div></a>
  <a class="navbar-brand" href="addStudent.php"><div class="btn btn-primary">Add Student</div></a>
  <a class="navbar-brand" href="addMark.php"><div class="btn btn-primary">Add Marks</div></a>
    <a class="navbar-brand" href="addExam.php"><div class="btn btn-primary">Exam Schedule</div> </a>
    <a class="navbar-brand" href="addSubject.php"><div class="btn btn-primary">Add Subject</div></a>
  <a class="navbar-brand" href="addRI.php" style="color: yellow"><div class="btn btn-primary">Retake/Improvement</div></a>
  <a  class="navbar-brand" href="index.php"><div class="btn btn-primary">Insert Image</div></a>
    <a  class="navbar-brand" href="qp\login.php"><div class="btn btn-primary">Question Paper Generate</div></a>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>

</nav>


<br>
<br>

<br>
<br>

<center>
<H1>Exam Schedule</H1>
    <form action="addExam.php" method="POST">
      
      <table>
        <tr>
          <th>
            Subject Name
          </th>
          <th>
            <input type="text" name="subjectName">
          </th>
        </tr>
        <tr>
          <th>
            Subject Code
          </th>
          <th>
            <input type="sec" name="subjectCode">
          </th>
        </tr>

        
        <tr>
          <th>
            Sem
          </th>
          <th>
            <input type="text" name="sem" value="<?php $sem=$_POST["sem"];if($sem)echo "$sem"; ?>">
          </th>
        </tr>
        <tr>
          <th>
           Date 
          </th>
          <th>
            <input type="text" name="date" value="<?php $date=$_POST["date"];if($date)echo "$date"; ?>">
          </th>
        </tr>
        <tr>
          <th>
           Time
          </th>
          <th>
            <input type="text" name="time" value="<?php $time=$_POST["time"];if($time)echo "$time"; ?>">
          </th>
        </tr>
        <tr>
          <th>
            Session
          </th>
          <th>
            <input type="text" name="session"   value="<?php $session=$_POST["session"];if($session)echo "$session"; ?>">
          </th>
        </tr>
         <tr>
          <th>
          Exam Name
          </th>
          <th>
            <input type="txt" name="examName" value=" <?php $exam=$_POST["exameName"];if($exam) echo "$exam"; ?>">
          </th>
        </tr>
        <tr><td></td><td><input type="submit" name="submit"></td></tr>
      </table>
    </form>
</center>

<form action="addExam.php" method="post">
  
<input type="submit" name="new" value="New Exam" >

</form>
</body>
</html>


<?php

$conn= mysqli_connect("localhost", "root", '', "ecautomationsystem");

$subjectCode=$_POST["subjectCode"];
$subjectName=$_POST["subjectName"];
$sem=$_POST["sem"];
$date=$_POST["date"];
$time=$_POST["time"];
$session=$_POST["session"];
$examName=$_POST["examName"];

if($sem){
$sql="insert into exam( sem, subjectName, subjectCode,date , time, session, examname) values( '$sem',  '$subjectName','$subjectCode','$date','$time','$session','$examName' )";
if (mysqli_query($conn,$sql)) {
 echo "<br><br><center>Successfully added</center>";
}
else
{
  echo "Not added";
}
}


?>

<?php 

$conn=mysqli_connect("localhost", "root", '', "ecautomationsystem");
if (isset($_POST["new"])) {
  $sql="drop table exam";
  if (mysqli_query($conn, $sql)) {
    $sql="create table exam(

subjectname varchar(100) not null,
subjectcode varchar(100) not null primary key,
date  varchar(100) not null,
time varchar(100) not null,
sem varchar(100) not null,
session varchar(100) not null,
examname  varchar(100) not null
)";


if (mysqli_query($conn,$sql)) {
  echo "Sucessfull";
  header("location: addExam.php");
}

else
echo "Try again";

$conn->close();
  }
}

?>
<?php

$conn = mysqli_connect("localhost","root",'', "ecautomationsystem");

$sql="create table currentsem(

id varchar(100) not null,
sem varchar(100) not null,
foreign KEY(id) references student

)";


if (mysqli_query($conn,$sql)) {
	echo "Sucessfull";
}

else
echo "Try again";

$conn->close();

?>
<?php

$conn = mysqli_connect("localhost","root",'', "ecautomationsystem");

$sql="CREATE Table student(

name varchar(100) not null,
id varchar(100) not null primary key,
email varchar(100) not null,
fathername varchar(100) not null,
mothername varchar(100) not null,
phonenumber varchar(100) not null,
address varchar(200) not null,
createdate timestamp default current_timestamp on update current_timestamp

)";


if (mysqli_query($conn,$sql)) {
	echo "Sucessfull";
}

else
echo "Try again";

$conn->close();

?>
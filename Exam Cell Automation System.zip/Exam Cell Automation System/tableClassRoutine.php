<?php

$conn = mysqli_connect("localhost","root",'', "ecautomationsystem");

$sql="create table classroutine(

subjectname varchar(100) not null,
teacher  varchar(100) not null,
time varchar(100) not null,
sem varchar(100) not null
)";


if (mysqli_query($conn,$sql)) {
	echo "Sucessfull";
}

else
echo "Try again";

$conn->close();

?>
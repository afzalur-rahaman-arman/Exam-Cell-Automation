<?php 
  session_start(); 

  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }
?>




<!DOCTYPE html>
<html lang="en">
<head>
 <title>Registration system PHP and MySQL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00fa9a">
​

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="admin.php" ><div class="btn btn-success">Home</div></a>
  <a class="navbar-brand" href="addStudent.php"><div class="btn btn-primary">Add Student</div></a>
  <a class="navbar-brand" href="addMark.php"><div class="btn btn-primary">Add Marks</div></a>
    <a class="navbar-brand" href="addExam.php"><div class="btn btn-primary">Exam Schedule</div> </a>
    <a class="navbar-brand" href="addSubject.php"><div class="btn btn-primary">Add Subject</div></a>
  <a class="navbar-brand" href="addRI.php" style="color: yellow"><div class="btn btn-primary">Retake/Improvement</div></a>
  <a  class="navbar-brand" href="index.php"><div class="btn btn-primary">Insert Image</div></a>
    <a  class="navbar-brand" href="qp\login.php"><div class="btn btn-primary">Question Paper Generate</div></a>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>

</nav>


<br>
<br>

<br>
<br>

<center>
<H1>Add Subject</H1>
    <form action="addSubject.php" method="POST">
      
      <table>
        
        <tr>
          <th>
            Subject Name
          </th>
          <th>
            <input type="text" name="subjectName">
          </th>
        </tr>
        <tr>
          <th>
            Subject Code
          </th>
          <th>
            <input type="text" name="subjectCode" >
          </th>
        </tr>
        <tr>
          <th>
            Sem
          </th>
          <th>
            <input type="text" name="sem" value="<?php $sem= $_POST["sem"]; if($sem) echo $sem; ?>">
          </th>
        </tr>
        <tr>
          <th>
            Credit
          </th>
          <th>
            <input type="number" name="credit"    value="<?php $credit= $_POST["credit"]; if($credit) echo $credit; ?>">
          </th>
        </tr>
        <tr><td></td><td><input type="submit" name="submit"></td></tr>
      </table>
    </form>
</center>

<a href="addCredit.php">Total credit</a>



</body>
</html>


<?php

$conn= mysqli_connect("localhost", "root", '', "ecautomationsystem");
$subjectName=$_POST["subjectName"];
$subjectCode=$_POST["subjectCode"];
$sem=$_POST["sem"];
$credit=$_POST["credit"];

if($sem){
$sql="insert into subject(subjectname, subjectcode, sem, credit ) values('$subjectName', '$subjectCode', '$sem','$credit' )";
if (mysqli_query($conn,$sql)) {
 echo "Successfully added";
}
else
{
  echo "Not added";
}
}


?>
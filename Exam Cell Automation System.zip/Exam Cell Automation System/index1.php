<?php 
  session_start(); 
  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }

  if (isset($_POST["submit1"])) {
    header("location: printAdmitCard.php");
  }
if (isset($_POST['submit'])) {
    header("location: printMarksheet.php");
  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
 <title> Profile </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">
​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index1.php" >Home</a>
  <a href="examSchedule.php" class="navbar-brand"> <div class="btn btn-success">Exam Schedule </div> </a>
    <div class="navbar-brand">
     <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printMarksheet.php" method="POST">
      <input type="submit" value="Marksheet" name="submit">
  </form>
<?php endif ?>
    </div>
     </div>

    <div class="navbar-brand"> 
      <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printAdmitCard.php" method="POST">
      <input type="submit" value="Admit Card" name="submit1">
  </form>
<?php endif ?>
    </div>
     </div>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout </div> 
  </a>

</nav>
<br>
<br>


<?php
$conn=mysqli_connect("localhost", "root", '', "ecautomationsystem");

$ID=$_SESSION['id'];
$fname="";
$mname="";
$email="";
$address="";
$id="";
$phonenumber="";
$name="";

 $sql = "SELECT * FROM student where id='$ID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc(); 

        $name=  $row["name"];
        $fname=$row["fathername"];
        $mname=$row["mothername"];
        $email=$row["email"];
        $phonenumber=$row["phonenumber"];
        $address=$row["address"];
        
}

echo "<h1><i>$name.......!!</h1></i><HR>";

echo "<center>";

  echo "<table><tr><th></th><th></th> <th></th></tr>";
 
echo "<tr><td>Name    :  </td>";//------------------ print name----------------//
echo "<td> <b><i><H4>$name</H4></i></b>";

echo "</td>";

echo "<td  rowspan='8'> ";

$sql="SELECT * FROM images where id='$ID'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      
      echo "<img src='".$row['image']."' width='200' height='250'>";//----image print----//
    }
}
echo "</td> </tr>";


echo "<tr> <td>ID   :  </td><td><b> $ID</b></td></tr>";//------ID---------//

 echo "<tr><td>Email : </td>";//------email-----//
 echo "<td>";
 echo "<a href='".$email."'><b>". $email."</b></a>";
 
echo "</td> </tr>";

echo "<tr>
  <td>
    Phone Number  :
  </td>
  <td><b>". $phonenumber."</b>
  </td>
</tr>
<tr>
  <td>
    Father's Name  :
  </td>
  <td><b>".$fname."</b> 
  </td>
</tr>

<tr>
  <td>
    Mother's Name  :
  </td>
  <td><b>".$mname."</b>
  </td>
</tr>

<tr>
  <td>
    Address  : 
  </td>
  <td><b>".$address."</b>
  </td>
</tr>";
echo "<tr><td> Program : </td>";

echo "<td><b> Bachelor of Science(Honours) in Computer Sci<b></td>";
echo "</tr></table>";
?>

</form>
<br>
<br>
<br>
<HR>
    
</center>

</body>
</html>



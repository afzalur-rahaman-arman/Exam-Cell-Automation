
CREATE TABLE `images` (
  `id` int(11) NOT NULL PRIMARY KEY,
  `name` varchar(200) NOT NULL,
  `image` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


<?php 
  session_start(); 
  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title>ProfileS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00FA9A">

​
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="index1.php" >Home</a>
  <a href="examSchedule.php" class="navbar-brand"> <div class="btn btn-success">Exam Schedule </div> </a>
<a href="printClassRoutine.php" class="navbar-brand"> <div class="btn btn-success">Class Schedule </div> </a>
    
    <div class="navbar-brand">
     <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printMarksheet.php" method="POST">
      <input type="submit" value="Marksheet" name="submit">
  </form>
<?php endif ?>
    </div>
     </div>

    <div class="navbar-brand"> 
      <div class="btn btn-success">
    <?php  if (isset($_SESSION['id'])) : ?>
   <form action="printAdmitCard.php" method="POST">
      <input type="submit" value="Admit Card" name="submit1">
  </form>
<?php endif ?>
    </div>
     </div>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout </div> 
  </a>

</nav>

<br>
<br>

<?php

echo "<h1 align='center'> BGC Trust University Bangladesh</h1>";
echo "<H4 align='center'> Exam Schedule</h4>";




echo "<table border='1'>
	<tr>
		<th>
			Date
		</th>
		<th>
			Subject
		</th>
		<th>
			Time
		</th>
		<th>
		Sem
		</th>
	</tr>";

$conn=mysqli_connect("localhost", "root", '', "ecautomationsystem");
$sql = "SELECT * FROM exam";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr><td> " . $row["date"]."</td>";
        echo "<td>". $row["subjectname"]."</td>";
        echo "<td>".$row["time"]."</td>";
        echo "<td>".$row["sem"]."</td></tr>";
    }
}
echo "</table>";


$conn->close();
?>

<br><br>

<button onclick="myFunction()">Print this page</button>
<script>
function myFunction()
{
window.print();
}
</script>
<br><br>

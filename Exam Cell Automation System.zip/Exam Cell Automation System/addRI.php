<?php 
  session_start(); 

  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }
?>


<!DOCTYPE html>
<html lang="en">
<head>
 <title>Registration system PHP and MySQL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00fa9a">
​

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="admin.php" ><div class="btn btn-success">Home</div></a>
  <a class="navbar-brand" href="addStudent.php"><div class="btn btn-primary">Add Student</div></a>
  <a class="navbar-brand" href="addMark.php"><div class="btn btn-primary">Add Marks</div></a>
    <a class="navbar-brand" href="addExam.php"><div class="btn btn-primary">Exam Schedule</div> </a>
    <a class="navbar-brand" href="addSubject.php"><div class="btn btn-primary">Add Subject</div></a>
  <a class="navbar-brand" href="addRI.php" style="color: yellow"><div class="btn btn-primary">Retake/Improvement</div></a>
  <a  class="navbar-brand" href="index.php"><div class="btn btn-primary">Insert Image</div></a>
    <a  class="navbar-brand" href="qp\login.php"><div class="btn btn-primary">Question Paper Generate</div></a>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>

</nav>



<br><br><br>

<center>
<H1>Add Student</H1>
    <form action="addRI.php" method="POST">
      
      <table>
        
        <tr>
          <th>
            Student ID
          </th>
          <th>
            <input type="text" name="id" value="<?php $id=$_POST["id"]; if($id) echo $id; ?>">
          </th>
        </tr>
        <tr>
          <th>
            Subject
          </th>
          <th>
            <input type="text" name="subject">
          </th>
        </tr>

        <tr>
          <th>
            Subject Code
          </th>
          <th>
            <input type="text" name="subjectCode">
          </th>
        </tr>

        <tr><td></td><td><input type="submit" name="submit"></td></tr>
      </table>

    </form>
</center>

<form action="addRI.php" method="post">
  
<input type="submit" name="new" value="New Exam" >

</form>



<br>
<br>
</body>
</html>



<?php

$conn= mysqli_connect("localhost", "root", '', "ecautomationsystem");
$id=$_POST["id"];
$subject=$_POST["subject"];
$subjectCode=$_POST["subjectCode"];

if($subjectCode){
$sql="insert into ri(id, subject, subjectcode) values('$id', '$subject', '$subjectCode' )";
if (mysqli_query($conn,$sql)) {
 echo "<br><br><center>Successfully added</center>";
}
else
{
  echo "<p style='background-color: red' >Not added</p>";
}
}


?>



<?php 

$conn=mysqli_connect("localhost", "root", '', "ecautomationsystem");
if (isset($_POST["new"])) {
  $sql="drop table ri";
  if (mysqli_query($conn, $sql)) {
 
 $sql ="create table ri(

id varchar(11) not null, 
subject varchar(50) not null,
subjectcode varchar(11) not null ,
foreign key(id) references student,
foreign key(subjectcode) references subject

)";


if (mysqli_query($conn,$sql)) {
  echo "Sucessfull";
}

else
echo "Try again";

$conn->close();
  }
}

?>
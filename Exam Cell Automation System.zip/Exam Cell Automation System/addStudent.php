<?php 
  session_start(); 

  if (!isset($_SESSION['id'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }
  if (isset($_GET['logout'])) {
    
    session_destroy();
    unset($_SESSION['id']);
    header("location: login.php");
  }
?>



<!DOCTYPE html>
<html lang="en">
<head>
 <title>Registration system PHP and MySQL</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #00fa9a">
​

<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
  <a class="navbar-brand" href="admin.php" ><div class="btn btn-success">Home</div></a>
  <a class="navbar-brand" href="addStudent.php"><div class="btn btn-primary">Add Student</div></a>
  <a class="navbar-brand" href="addMark.php"><div class="btn btn-primary">Add Marks</div></a>
    <a class="navbar-brand" href="addExam.php"><div class="btn btn-primary">Exam Schedule</div> </a>
    <a class="navbar-brand" href="addSubject.php"><div class="btn btn-primary">Add Subject</div></a>
  <a class="navbar-brand" href="addRI.php" style="color: yellow"><div class="btn btn-primary">Retake/Improvement</div></a>
  <a  class="navbar-brand" href="index.php"><div class="btn btn-primary">Insert Image</div></a>
    <a  class="navbar-brand" href="qp\login.php"><div class="btn btn-primary">Question Paper Generate</div></a>

  <a class="navbar-brand" href="index1.php?logout='1'" style="color: red;"> <div class="btn btn-danger">Logout</div></a>

</nav>
<br>
<br>


<br>
<br>

<center>
<H1>Add Student</H1>
    <form action="addStudent.php" method="POST">
      
      <table>
        
        <tr>
          <th>
            Student Name
          </th>
          <th>
            <input type="text" name="name">
          </th>
        </tr>
        <tr>
          <th>
           ID
          </th>
          <th>
            <input type="text" name="id">
          </th>
        </tr>
        <tr>
          <th>
            Email
          </th>
          <th>
            <input type="email" name="email">
          </th>
        </tr>

        <tr>
          <th>
            Phone number
          </th>
          <th>
            <input type="text" name="phonenumber">
          </th>
        </tr>
        
          <th>
            Father's Name
          </th>
          <th>
            <input type="text" name="fathername">
          </th>
        </tr>
        <tr>
          <th>
         Mother's Name
          </th>
          <th>
            <input type="text" name="mothername">
          </th>
        </tr>
        <tr>
          <th>
         Address
          </th>
          <th>
            <input type="text" name="address">
          </th>
        </tr>

        <tr><td></td><td><input type="submit" name="submit"></td></tr>
      </table>

    </form>
</center>
<br><br>
<center><a href="index.php"><div class="btn btn-primary">Insert Image</div></a></center>

</body>
</html>


<?php

$conn= mysqli_connect("localhost", "root", '', "ecautomationsystem");
$name=$_POST["name"];
$email=$_POST["email"];
$id=$_POST["id"];
$phonenumber=$_POST["phonenumber"];
$fathername=$_POST["fathername"];
$mothername=$_POST["mothername"];
$address=$_POST["address"];

if($id){
$sql="insert into student(name, email, id, phonenumber, fathername, mothername, address) values('$name', '$email', '$id', '$phonenumber', '$fathername', '$mothername', '$address' )";
if (mysqli_query($conn,$sql)) {
 echo "<br><br><center>Successfully added</center>";
}
else
{
  echo "Not added";
}
}


?>